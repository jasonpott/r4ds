#KNITR setup
knitr::opts_chunk$set(echo = TRUE, warning=TRUE, message = TRUE)
options(stringsAsFactors = FALSE)

#Package load
pacman::p_load(drake, tidyverse, tidylog, kableExtra, lubridate, readxl, janitor)

#Function load 
